// SELECT SECTIONS AND NAV LINKS
const sections = document.querySelectorAll("div[id]");
const navLinks = document.querySelectorAll(".nav ul a");

// SCROLL EVENT (AUTO ACTIVE NAV)
window.addEventListener("scroll", () => {
    let current = "";

    sections.forEach(section => {
        const sectionTop = section.offsetTop - 100;
        const sectionHeight = section.clientHeight;

        if (pageYOffset >= sectionTop) {
            current = section.getAttribute("id");
        }
    });

    navLinks.forEach(link => {
        link.classList.remove("active");
        if (link.getAttribute("href") === "#" + current) {
            link.classList.add("active");
        }
    });
});

// CLICK EVENT (ACTIVE NAV ON CLICK)
navLinks.forEach(link => {
    link.addEventListener("click", function() {
        navLinks.forEach(l => l.classList.remove("active"));
        this.classList.add("active");
    });
});